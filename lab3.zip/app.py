import connexion
from connexion import NoContent
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from base import Base
from food_and_water_readings import FoodAndWaterReadings
from cage_readings import CageReadings


MAX_EVENTS = 10
FILENAME = "events.json"

DB_ENGINE = create_engine("sqlite:///readings.sqlite")
Base.metadata.bind = DB_ENGINE
DB_SESSION = sessionmaker(bind=DB_ENGINE)


def extract_from_body(d, *keys):
    return [d[k] if k in d else None for k in keys]


def test_food_and_water(body):
    session = DB_SESSION()
    for reading in body:
        name = reading["name"]
        del reading["name"]
        keys = list(reading.keys())
        values = list(reading.values())
        while len(keys) < 5:
            keys.append(None)
            values.append(None)
        [
            var1_name,
            var2_name,
            var3_name,
            var4_name,
            var5_name,
        ] = keys
        [
            var1_value,
            var2_value,
            var3_value,
            var4_value,
            var5_value
        ] = values
        data_entry = FoodAndWaterReadings(name, var1_name, var1_value, var2_name, var2_value, var3_name, var3_value, var4_name, var4_value, var5_name, var5_value)
        session.add(data_entry)
        session.commit()
    session.close()
    return NoContent, 201


def test_cage_readings(body):
    session = DB_SESSION()
    [
        temperature,
        humidity_percentage,
        air_quality_percentage,
        lux,
        dropping_buildup_percentage,
        bird_locations
    ] = extract_from_body(
        body,
        "temperature",
        "humidity_percentage",
        "air_quality_percentage",
        "lux",
        "dropping_buildup_percentage",
        "bird_locations"
    )
    data_entry = CageReadings(temperature, humidity_percentage, air_quality_percentage, lux, dropping_buildup_percentage, bird_locations)
    session.add(data_entry)
    session.commit()
    session.close()
    return NoContent, 201


app = connexion.FlaskApp(__name__, specification_dir="")
app.add_api("openapi.yml", strict_validation=True, validate_responses=True)

if __name__ == '__main__':
    app.run(port=8090)
